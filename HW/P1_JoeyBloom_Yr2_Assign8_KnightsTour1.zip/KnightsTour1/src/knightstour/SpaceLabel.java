package knightstour;

import javax.swing.JLabel;

/**
Assignment #8
Acts as a JLabel, but also stores the space's location on
the chessboard
@author Joey Bloom
 */
public class SpaceLabel extends JLabel
{
    private int r,c;

    public SpaceLabel(String str, int r, int c)
    {
        super(str);
        this.r = r;
        this.c = c;
    }
    
    public SpaceLabel(int r, int c)
    {
        super();
        this.r = r;
        this.c = c;
    }

    public int getR()
    {
        return r;
    }

    public int getC()
    {
        return c;
    }
}
