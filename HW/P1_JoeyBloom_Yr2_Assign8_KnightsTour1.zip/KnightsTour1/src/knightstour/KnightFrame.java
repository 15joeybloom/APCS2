package knightstour;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.InvocationTargetException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

/**
Assignment #8
 @author Joey Bloom
 */
public class KnightFrame extends JFrame
{
    private JPanel chessBoard;
    private SpaceLabel[][] grid;

    private JPanel buttonPanel;
    private JButton step;
    private JButton finish;
    private JButton clear;

    /**
    Constructs a new KnightFrame.
    */
    public KnightFrame()
    {
        setSize(500,500);
        setTitle("Knight's Tour");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        BorderLayout layout = new BorderLayout();
        layout.setHgap(0);
        layout.setVgap(0);
        setLayout(layout);

        setUpChessBoard();
        setUpGrid();
        setUpButtons();

        setVisible(true);
        clear.doClick();
    }

    /**
    Sets up the JPanel that holds the spaces on the board.
    */
    private void setUpChessBoard()
    {
        chessBoard = new JPanel();
        chessBoard.setLayout(new GridLayout(8,8));
        chessBoard.setOpaque(false);

        add(chessBoard, BorderLayout.CENTER);
    }

    /**
    Sets up the grid of JLabels.
    */
    private void setUpGrid()
    {
        grid = new SpaceLabel[8][];
        for(int i = 0; i < 8; i++)
        {
            grid[i] = new SpaceLabel[8];
            for(int j = 0; j < 8; j++)
            {
                grid[i][j] = new SpaceLabel("0",i,j);
                grid[i][j].setHorizontalAlignment(JLabel.CENTER);
                if((i+j) % 2 == 0)
                {
                    grid[i][j].setBackground(Color.BLACK);
                    grid[i][j].setForeground(Color.WHITE);
                }
                else
                {
                    grid[i][j].setBackground(Color.WHITE);
                    grid[i][j].setForeground(Color.BLACK);
                }
                grid[i][j].setOpaque(true);
                chessBoard.add(grid[i][j]);
            }
        }
    }

    /**
    Sets up the buttons on the right
    */
    private void setUpButtons()
    {
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new BorderLayout());
        add(buttonPanel,BorderLayout.SOUTH);

        Color red = new Color(194,0,0);
        step = new JButton("Step");
        step.setBackground(red);
        step.setForeground(Color.yellow);
        step.addActionListener(new StepListener());
        buttonPanel.add(step,BorderLayout.CENTER);

        finish = new JButton("Finish");
        finish.setBackground(red);
        finish.setForeground(Color.yellow);
        finish.addActionListener(new FinishListener());
        buttonPanel.add(finish,BorderLayout.EAST);

        clear = new JButton("Clear");
        clear.setBackground(red);
        clear.setForeground(Color.yellow);
        clear.addActionListener(new ClearListener());
        buttonPanel.add(clear,BorderLayout.WEST);
    }

    private Random rand = new Random();
    private static final int[] horz = {-2,-1,1,2,2,1,-1,-2};
    private static final int[] vert = {1,2,2,1,-1,-2,-2,-1};
    private SpaceLabel knightSpace;
    private int counter;
    private boolean done;

    /**
    Sets the text of all of the spaces to "0"
    Resets counter
    Puts the knight back at 1,1
    */
    private void clearBoard()
    {
        for(JLabel[] xs : grid)
        {
            for(JLabel x : xs)
            {
                x.setText("");
            }
        }
        done = false;
        knightSpace = grid[0][0];
        counter = 0;
        knightSpace.setText(Integer.toString(++counter));
        knightSpace.setForeground(Color.blue);
    }

    private class ClearListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            clearBoard();
        }
    }

    private class StepListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            if(done)
            {
                JOptionPane.showMessageDialog(KnightFrame.this,"Touched " + counter + " spaces");
                return;
            }
            //assemble the available spaces to move to
            ArrayList<SpaceLabel> choices = new ArrayList<>();
            for(int i = 0; i < 8; i++)
            {
                try
                {
                    SpaceLabel x = grid[knightSpace.getR()+vert[i]][knightSpace.getC()+horz[i]];
                    if(x.getText().equals(""))
                    {
                        choices.add(x);
                    }
                }
                catch(ArrayIndexOutOfBoundsException ex){}
            }
            if(choices.isEmpty())
            {
                JOptionPane.showMessageDialog(KnightFrame.this, "Touched " + counter + " spaces");
                done = true;
                return;
            }

            //restore previous knightspace's text color
            knightSpace.setForeground((knightSpace.getR()+knightSpace.getC()) % 2 == 0 ? Color.white : Color.black);

            //since there are available spaces, choose one and move to it.
            knightSpace = choices.get(rand.nextInt(choices.size()));
            knightSpace.setText(Integer.toString(++counter));

            //make the text blue of the space to which we just moved
            knightSpace.setForeground(Color.blue);
        }
    }

    private class FinishListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            //using a SwingWorker allows the clicking of step to run in
            //the background, so that the user can actually see
            //the clicking occur and the user can see
            //the knight moving.
            new SwingWorker<Void,Void>(){
                @Override
                public Void doInBackground() throws InterruptedException
                {
                    do
                    {
                        //finish the tour by clicking step repeatedly
                        step.doClick();
                        try
                        {
                            //slow down the clicking of step
                            Thread.sleep(200);
                        }
                        catch(InterruptedException ex){}
                    }while(!done);
                    return null;
                }
            }.execute();
        }
    }


    public static void main(String[] args) throws InterruptedException, InvocationTargetException
    {
        SwingUtilities.invokeAndWait(new Runnable(){
            @Override
            public void run()
            {
                KnightFrame frame = new KnightFrame();
            }
        });
    }
}
