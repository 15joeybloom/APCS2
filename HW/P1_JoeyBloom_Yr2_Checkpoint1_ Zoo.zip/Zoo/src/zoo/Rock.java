package zoo;

import java.awt.Color;

/**
 A Rock is the most basic implementation of <code>Entity</code>; it does nothing,
 (because it is a rock) and it has a neutral smell.
 @author Joey Bloom
 */
public class Rock implements Entity
{
    private Color color;
    private double visibility;
    private int size;
    private double x;
    private double y;

    /**
    Constructs a black, invisible, infinitesimally small Rock at (0,0)
    */
    public Rock()
    {
        this(Color.black,0.0,0,0.0,0.0);
    }
    /**
    Constructs a Rock
    @param c Color of the Rock
    @param vis visibility
    @param siz size
    @param x horizontal coordinate
    @param y vertical coordinate
    */
    public Rock(Color c, double vis, int siz, double x, double y)
    {
        color = c;
        visibility = vis;
        size = siz;
        this.x = x;
        this.y = y;
    }
    /**
    Returns 0; Rocks are odorless
    @return 0
    */
    @Override
    public int getSmell()
    {
        return 0;
    }

    @Override
    public Color getColor()
    {
        return color;
    }

    @Override
    public double getVisibility()
    {
        return visibility;
    }

    @Override
    public int getSize()
    {
        return size;
    }

    @Override
    public double getX()
    {
        return x;
    }

    @Override
    public double getY()
    {
        return y;
    }

    @Override
    public double getDistanceFrom(double x, double y)
    {
        return Math.hypot(this.x - x, this.y - y);
    }
}
