package zoo;

import java.awt.Color;

/**
 <p/>
 @author Joey Bloom
 */
public abstract class AbstractAnimal implements Entity
{
    private int smell;
    private Color color;
    private double visibility;
    private int size;
    private double x;
    private double y;

    /**
     Constructs an odorless, black, invisible, infinitesimally small
     AbstractAnimal at (0,0)
     */
    public AbstractAnimal()
    {
        this(0, Color.black, 0.0, 0, 0.0, 0.0);
    }

    /**
     Constructs an AbstractAnimal
     <p>
     @param smell smell
     @param c     Color of the AbstractAnimal
     @param vis   visibility
     @param siz   size
     @param x     horizontal coordinate
     @param y     vertical coordinate
     */
    public AbstractAnimal(int smell, Color c, double vis, int siz, double x, double y)
    {
        this.smell = smell;
        color = c;
        visibility = vis;
        size = siz;
        this.x = x;
        this.y = y;
    }

    /**
     Animals evaluate entities by “scoring” them based on their properties.
     Small, distant, entities with a low smell value and a low visibility
     value (meaning they are well camouflaged, or otherwise hidden from view)
     and a {@link java.awt.Color Color} with a low saturation value
     will be scored relatively low, and large, close, smelly, obviously
     visible entities with a highly saturated Color will be scored high.
     Low scored entities will be
     ignored by the animal, while high scored entities will cause the animal
     to take some action, whether it is running, hiding, eating, playing,
     or other action.
     <p>
     @param e {@literal Entity} to be scored
     @return an integer value representing this animal's attraction or repulsion
             to e
     */
    protected int score(Entity e)
    {
        int eSmell = e.getSmell();
        Color eColor = e.getColor();
        double eSaturation = Color.RGBtoHSB(eColor.getRed(), eColor.getGreen(), eColor.getBlue(), null)[1]; //get saturation value
        eSaturation++;  //if the saturation is 0,
                        //then the score will be multiplied by 1 and so
                        //saturation will be ignored. if saturation is high,
                        //score will be multiplied by 2.
        double eVisibility = e.getVisibility();
        int eSize = e.getSize() / (size == 0 ? 1 : size); //divide by animal's own size so that Entity's relative size is used in calculation.
        double eDistance = e.getDistanceFrom(x, y);

        return (int) ( (eSmell == 0 ? 1 : eSmell) * eSaturation * eVisibility * eSize / eDistance);
        //divide by distance so that more distant Entities lower the score because they are less important

        //smell is the only one
        //of these that can be negative, so it determines the sign of the score and
        //thus determines whether e is attractive or repulsive. if smell is 0,
        //make it 1 so that it has no effect on the multiplication and is thus
        //ignored. This means that if an animal sees an Entity but can't smell it,
        //it will be naturally curious and be attracted to it.
    }

    /**
     Moves this animal by a horizontal change and a vertical change
     <p>
     @param x horizontal change in meters
     @param y vertical change in meters
     */
    protected abstract void move(double x, double y);

    @Override
    public int getSmell()
    {
        return smell;
    }

    @Override
    public Color getColor()
    {
        return color;
    }

    @Override
    public double getVisibility()
    {
        return visibility;
    }

    @Override
    public int getSize()
    {
        return size;
    }

    @Override
    public double getX()
    {
        return x;
    }

    @Override
    public double getY()
    {
        return y;
    }

    @Override
    public double getDistanceFrom(double x, double y)
    {
        return Math.hypot(this.x - x, this.y - y);
    }
}
