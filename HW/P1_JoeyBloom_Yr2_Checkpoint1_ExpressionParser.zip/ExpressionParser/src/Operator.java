
import java.util.*;
import groovy.lang.Binding;
import groovy.lang.GroovyShell;
import groovy.lang.Script;
import static org.codehaus.groovy.jsr223.ScriptExtensions.eval;

/**
 An Operator takes a fixed number of numeric arguments and calculates a
 numeric results.
 Checkpoint 1
 <p>
 @author Joey Bloom
 */
public class Operator
{
    private final Script script;
    private final int numArgs;

    private static final GroovyShell shell = new GroovyShell();
    public static Map<String, Operator> symbolMap = new HashMap<>();

    static
    {
        new Operator("+", 2, shell.parse("a + b;"));
        new Operator("-", 2, shell.parse("a - b;"));
        new Operator("*", 2, shell.parse("a * b;"));
        new Operator("/", 2, shell.parse("a / b;"));
        new Operator("^", 2, shell.parse("Math.pow(a,b);"));
        new Operator("sqrt", 1, shell.parse("Math.sqrt(a)"));
    }
    /**
     This is simply the lowercase alphabet. These chars are the vars
     used by the user to represent the arguments for their user defined
     operation.
     */
    public static final String[] vars =
    {
        "a", "b", "c", "d", "e",
        "f", "g", "h", "i", "j", "k",
        "l", "m", "n", "o", "p",
        "q", "r", "s", "t", "u",
        "v", "w", "x", "y", "z"
    };

    /**
     Constructs an Operator which performs a user-defined operation
     using the script and is represented by the symbol. This constructor
     is only used directly for standard Operators like +, -, *, / that are
     predefined
     in the application, not user-defined.
     <p>
     @param symbol  represents this Operator
     @param numArgs the number of arguments taken by this Operator
     @param script  the script that this Operator performs
     */
    private Operator(String symbol, int numArgs, Script script)
    {
        this.script = script;
        this.numArgs = numArgs;
        symbolMap.put(symbol, this);
    }

    /**
     Constructs an Operator which performs a user-defined operation
     and is represented by a symbol.
     <p>
     @param symbol    used to represent the operation in expressions
     @param numArgs   number of arguments taken by this Operator
     @param operation the computation performed when this operator is specified.
     */
    public Operator(String symbol, int numArgs, String operation)
    {
        script = shell.parse(toCode(new StringTokenizer(operation)) + ";");
        this.numArgs = numArgs;
        symbolMap.put(symbol, this);
    }

    /**
     Returns the tokens in the tokenizer into code. The tokenizer
     should be all or part of a prefix notation sequence
     <p>
     @param tokenizer
     @return
     */
    private String toCode(StringTokenizer tokenizer)
    {
        if(!tokenizer.hasMoreTokens()) return "";
        String str = tokenizer.nextToken();
        if(str.matches("\\d*") || str.matches("[a-z]"))//if it's a number or variable
        {
            return str;
        }
        else //if it's an operator
        {
            int n = symbolMap.get(str).getNumArgs();
            String returnMe = "map.get(\"" + str + "\").eval(";
            if(n-- > 0)
            {
                returnMe += toCode(tokenizer);
                while(n-- > 0)
                {
                    returnMe += "," + toCode(tokenizer);
                }
            }
            returnMe += ")";
            return returnMe;
        }
    }

    /**
     Returns the number of arguments this operation takes.
     <p>
     @return the number of arguments accepted by this operator.
     */
    public int getNumArgs()
    {
        return numArgs;
    }

    /**
     Calculates this operation with the given arguments.
     <p>
     @param args The arguments for this operation.
     @return the result of calculating this operation.
     @throws RuntimeException if args.length != getNumArgs
     */
    public double eval(double... args)
    {
        if(args.length == numArgs)
        {
            Binding binding = new Binding();
            for(int i = 0; i < args.length; i++)
            {
                binding.setVariable(vars[i], args[i]);
            }
            binding.setVariable("map", symbolMap);
            script.setBinding(binding);
            return (Double) script.run();
        }
        else throw new RuntimeException("incorrect number of arguments");
    }
}
