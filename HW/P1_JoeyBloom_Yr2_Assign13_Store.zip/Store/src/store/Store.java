package store;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

/**
 * Assignment #13
 * @author Joey Bloom
 */
public class Store 
{
    private Item[] myStore;
    
    /**
     * Constructs a Store with the Items described in the file
     * at the location specified by filename
     * @param fileName the name of the file with the items
     * @throws IOException if the file cannot be found
     */
    public Store(String fileName) throws IOException
    {
        loadFile(fileName);
    }
    
    private void loadFile(String inFileName) throws IOException
    {
        try(BufferedReader in = new BufferedReader(new InputStreamReader(Store.class.getResourceAsStream(inFileName))))
        {
            int numItems = Integer.parseInt(in.readLine());
            myStore = new Item[numItems];
            for(int i = 0; i < numItems; i++)
            {
                StringTokenizer tokenizer = new StringTokenizer(in.readLine());
                int id = Integer.parseInt(tokenizer.nextToken());
                int inv = Integer.parseInt(tokenizer.nextToken());
                myStore[i] = new Item(id,inv);
            }
        }
    }
}
