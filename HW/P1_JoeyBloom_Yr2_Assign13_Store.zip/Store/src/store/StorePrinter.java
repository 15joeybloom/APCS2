package store;

/**
 *Assignment #13
 * @author Joey Bloom
 */
public class StorePrinter 
{
    public static void main(String[] args) 
    {
        
    }
}
