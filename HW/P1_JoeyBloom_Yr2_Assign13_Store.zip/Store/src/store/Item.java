package store;

/**
 * Assignment #13
 * @author Joey Bloom
 */
public class Item implements Comparable
{
    private int myId;
    private int myInv;
    
    public Item(int id, int inv)
    {
        myId = id;
        myInv = inv;
    }
    
    public int getId()
    {
        return myId;
    }
    
    public int getInv()
    {
        return myInv;
    }
    
    @Override
    public int compareTo(Object o) 
    {
        return getId() - ((Item)o).getId();
    }
    
    @Override
    public boolean equals(Object otherObject)
    {
        return compareTo(otherObject) == 0;
    }
    
    @Override
    public String toString()
    {
        return 
              "ID:  " + getId() +
            "\nInv: " + getInv();
            
    }
}
